// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportConfig = require('../../../app/model/config');
import ExportDaka = require('../../../app/model/daka');
import ExportGonggao = require('../../../app/model/gonggao');
import ExportUser = require('../../../app/model/user');
import ExportYudin = require('../../../app/model/yudin');

declare module 'egg' {
  interface IModel {
    Config: ReturnType<typeof ExportConfig>;
    Daka: ReturnType<typeof ExportDaka>;
    Gonggao: ReturnType<typeof ExportGonggao>;
    User: ReturnType<typeof ExportUser>;
    Yudin: ReturnType<typeof ExportYudin>;
  }
}
