// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportApi = require('../../../app/controller/api');
import ExportHome = require('../../../app/controller/home');

declare module 'egg' {
  interface IController {
    api: ExportApi;
    home: ExportHome;
  }
}
